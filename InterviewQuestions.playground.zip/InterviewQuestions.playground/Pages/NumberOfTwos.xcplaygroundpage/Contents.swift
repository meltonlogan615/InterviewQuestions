import Foundation

/**
 Create a function that receives an `Int` and returns the number of instances of the number "2"
 
 Example 12 -> 2
 1, <2>, 3, 4, 5, 6, 7, 8, 9, 1-0, 1-1, 1-<2>
*/
